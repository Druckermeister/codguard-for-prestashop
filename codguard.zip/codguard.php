<?php
/**
 * CodGuard for PrestaShop
 *
 * @package    CodGuard
 * @author     CodGuard
 * @copyright  2025 CodGuard
 * @license    GPL v2 or later
 * @version    1.0.0
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

class CodGuard extends Module
{
    /**
     * API endpoint for customer rating
     */
    const API_RATING_ENDPOINT = 'https://api.codguard.com/api/customer-rating';

    public function __construct()
    {
        $this->name = 'codguard';
        $this->tab = 'checkout';
        $this->version = '1.0.0';
        $this->author = 'CodGuard';
        $this->need_instance = 0;
        $this->ps_versions_compliancy = array('min' => '1.7', 'max' => _PS_VERSION_);
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('CodGuard - COD Fraud Prevention');
        $this->description = $this->l('Validates customer ratings and disables Cash on Delivery for high-risk customers.');

        $this->confirmUninstall = $this->l('Are you sure you want to uninstall CodGuard?');
    }

    /**
     * Install module
     */
    public function install()
    {
        if (!parent::install()) {
            return false;
        }

        // Create database tables
        if (!$this->createTables()) {
            return false;
        }

        // Register hooks
        if (!$this->registerHook('paymentOptions') ||
            !$this->registerHook('actionValidateOrder')) {
            return false;
        }

        // Set default configuration
        Configuration::updateValue('CODGUARD_RATING_TOLERANCE', 35);
        Configuration::updateValue('CODGUARD_REJECTION_MESSAGE',
            'Unfortunately, we cannot offer Cash on Delivery for this order. Please choose a different payment method.');
        Configuration::updateValue('CODGUARD_ENABLED', false);

        return true;
    }

    /**
     * Uninstall module
     */
    public function uninstall()
    {
        if (!parent::uninstall()) {
            return false;
        }

        // Remove configuration
        Configuration::deleteByName('CODGUARD_SHOP_ID');
        Configuration::deleteByName('CODGUARD_PUBLIC_KEY');
        Configuration::deleteByName('CODGUARD_PRIVATE_KEY');
        Configuration::deleteByName('CODGUARD_RATING_TOLERANCE');
        Configuration::deleteByName('CODGUARD_REJECTION_MESSAGE');
        Configuration::deleteByName('CODGUARD_ENABLED');

        // Drop database tables
        Db::getInstance()->execute('DROP TABLE IF EXISTS `'._DB_PREFIX_.'codguard_block_events`');
        Db::getInstance()->execute('DROP TABLE IF EXISTS `'._DB_PREFIX_.'codguard_settings`');

        return true;
    }

    /**
     * Create database tables
     */
    private function createTables()
    {
        $sql = array();

        // Block events table
        $sql[] = 'CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'codguard_block_events` (
            `id_block_event` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
            `email` VARCHAR(255) NOT NULL,
            `rating` DECIMAL(3,2) NOT NULL,
            `timestamp` INT(11) NOT NULL,
            `ip_address` VARCHAR(45) NOT NULL,
            PRIMARY KEY (`id_block_event`),
            INDEX `email` (`email`),
            INDEX `timestamp` (`timestamp`)
        ) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8;';

        // Settings persistence table (backup for configuration)
        $sql[] = 'CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'codguard_settings` (
            `id_setting` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
            `setting_key` VARCHAR(255) NOT NULL,
            `setting_value` TEXT,
            PRIMARY KEY (`id_setting`),
            UNIQUE KEY `setting_key` (`setting_key`)
        ) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8;';

        foreach ($sql as $query) {
            if (!Db::getInstance()->execute($query)) {
                return false;
            }
        }

        return true;
    }

    /**
     * Hook into payment options to filter COD if customer rating is low
     */
    public function hookPaymentOptions($params)
    {
        // Only process if module is enabled
        if (!Configuration::get('CODGUARD_ENABLED')) {
            return;
        }

        // Get customer email
        $customer = $this->context->customer;
        $email = null;

        if ($customer && $customer->email) {
            $email = $customer->email;
        } else {
            // Try to get email from cart/guest checkout
            $cart = $params['cart'];
            if (isset($cart->id)) {
                $address = new Address((int)$cart->id_address_invoice);
                if (Validate::isLoadedObject($address)) {
                    $customer_obj = new Customer((int)$address->id_customer);
                    if (Validate::isLoadedObject($customer_obj)) {
                        $email = $customer_obj->email;
                    }
                }
            }
        }

        // If no email found, allow all payment methods (fail-open)
        if (!$email) {
            PrestaShopLogger::addLog('CodGuard: No customer email found, allowing all payment methods', 1);
            return;
        }

        // Get customer rating
        $rating = $this->getCustomerRating($email);

        // If API fails, allow all payment methods (fail-open)
        if ($rating === null) {
            PrestaShopLogger::addLog('CodGuard: API failed for '.$email.', allowing all payment methods', 1);
            return;
        }

        // Check rating tolerance
        $tolerance = (int)Configuration::get('CODGUARD_RATING_TOLERANCE');
        $rating_percentage = $rating * 100;

        PrestaShopLogger::addLog('CodGuard: Customer '.$email.' rating: '.$rating_percentage.'% (tolerance: '.$tolerance.'%)', 1);

        // If rating is below tolerance, block COD
        if ($rating_percentage < $tolerance) {
            // Log block event
            $this->logBlockEvent($email, $rating);

            // Set warning message in session
            $rejection_message = Configuration::get('CODGUARD_REJECTION_MESSAGE');
            $this->context->controller->warnings[] = $rejection_message;

            PrestaShopLogger::addLog('CodGuard: Blocked COD for '.$email.' (rating: '.$rating_percentage.'%)', 2);
        }
    }

    /**
     * Get customer rating from CodGuard API
     *
     * @param string $email Customer email
     * @return float|null Rating (0-1) or null on failure
     */
    private function getCustomerRating($email)
    {
        $shop_id = Configuration::get('CODGUARD_SHOP_ID');
        $public_key = Configuration::get('CODGUARD_PUBLIC_KEY');

        if (empty($shop_id) || empty($public_key)) {
            PrestaShopLogger::addLog('CodGuard [ERROR]: API keys not configured', 3);
            return null;
        }

        $url = self::API_RATING_ENDPOINT.'/'.$shop_id.'/'.urlencode($email);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        curl_setopt($ch, CURLOPT_HEADER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Accept: application/json',
            'x-api-key: '.$public_key
        ));

        $full_response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curl_error = curl_error($ch);
        $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);

        $response = substr($full_response, $header_size);

        curl_close($ch);

        PrestaShopLogger::addLog('CodGuard [INFO]: Rating API called for '.$email.' - HTTP '.$http_code, 1);

        if ($curl_error) {
            PrestaShopLogger::addLog('CodGuard [ERROR]: cURL error - '.$curl_error, 3);
            return null;
        }

        // 404 = new customer, return 1.0 (allow)
        if ($http_code == 404) {
            PrestaShopLogger::addLog('CodGuard [INFO]: Customer not found (404) - allowing with rating 1.0', 1);
            return 1.0;
        }

        // Non-200 status, fail open
        if ($http_code != 200) {
            PrestaShopLogger::addLog('CodGuard [ERROR]: API returned non-200 status: '.$http_code, 3);
            return null;
        }

        $data = json_decode($response, true);

        if (json_last_error() !== JSON_ERROR_NONE) {
            PrestaShopLogger::addLog('CodGuard [ERROR]: JSON decode error: '.json_last_error_msg(), 3);
            return null;
        }

        if (!isset($data['rating'])) {
            PrestaShopLogger::addLog('CodGuard [ERROR]: Invalid API response - missing "rating" field', 3);
            return null;
        }

        $rating = (float)$data['rating'];
        PrestaShopLogger::addLog('CodGuard [INFO]: Customer rating retrieved: '.$rating, 1);

        return $rating;
    }

    /**
     * Log block event
     *
     * @param string $email Customer email
     * @param float $rating Customer rating
     */
    private function logBlockEvent($email, $rating)
    {
        $ip_address = Tools::getRemoteAddr();

        Db::getInstance()->execute('
            INSERT INTO `'._DB_PREFIX_.'codguard_block_events`
            (email, rating, timestamp, ip_address)
            VALUES ("'.pSQL($email).'", '.(float)$rating.', '.time().', "'.pSQL($ip_address).'")
        ');

        PrestaShopLogger::addLog('CodGuard: Blocked COD for '.$email.' (rating: '.($rating * 100).'%)', 2);
    }

    /**
     * Configuration page
     */
    public function getContent()
    {
        $output = '';

        // Handle form submission
        if (Tools::isSubmit('submitCodGuardModule')) {
            $shop_id = Tools::getValue('CODGUARD_SHOP_ID');
            $public_key = Tools::getValue('CODGUARD_PUBLIC_KEY');
            $private_key = Tools::getValue('CODGUARD_PRIVATE_KEY');
            $rating_tolerance = (int)Tools::getValue('CODGUARD_RATING_TOLERANCE');
            $rejection_message = Tools::getValue('CODGUARD_REJECTION_MESSAGE');
            $enabled = Tools::getValue('CODGUARD_ENABLED');

            // Validation
            if (empty($shop_id)) {
                $output .= $this->displayError($this->l('Shop ID is required.'));
            } elseif (empty($public_key) || strlen($public_key) < 10) {
                $output .= $this->displayError($this->l('Public Key is required (minimum 10 characters).'));
            } elseif (empty($private_key) || strlen($private_key) < 10) {
                $output .= $this->displayError($this->l('Private Key is required (minimum 10 characters).'));
            } else {
                Configuration::updateValue('CODGUARD_SHOP_ID', $shop_id);
                Configuration::updateValue('CODGUARD_PUBLIC_KEY', $public_key);
                Configuration::updateValue('CODGUARD_PRIVATE_KEY', $private_key);
                Configuration::updateValue('CODGUARD_RATING_TOLERANCE', $rating_tolerance);
                Configuration::updateValue('CODGUARD_REJECTION_MESSAGE', $rejection_message);
                Configuration::updateValue('CODGUARD_ENABLED', $enabled);

                $output .= $this->displayConfirmation($this->l('Settings updated successfully.'));
            }
        }

        return $output . $this->displayForm();
    }

    /**
     * Display configuration form
     */
    public function displayForm()
    {
        $default_lang = (int)Configuration::get('PS_LANG_DEFAULT');

        $fields_form[0]['form'] = array(
            'legend' => array(
                'title' => $this->l('CodGuard API Configuration'),
            ),
            'input' => array(
                array(
                    'type' => 'switch',
                    'label' => $this->l('Enable CodGuard'),
                    'name' => 'CODGUARD_ENABLED',
                    'is_bool' => true,
                    'desc' => $this->l('Enable or disable the CodGuard module'),
                    'values' => array(
                        array(
                            'id' => 'active_on',
                            'value' => 1,
                            'label' => $this->l('Enabled')
                        ),
                        array(
                            'id' => 'active_off',
                            'value' => 0,
                            'label' => $this->l('Disabled')
                        )
                    ),
                ),
                array(
                    'type' => 'text',
                    'label' => $this->l('Shop ID'),
                    'name' => 'CODGUARD_SHOP_ID',
                    'required' => true,
                    'desc' => $this->l('Your CodGuard shop ID'),
                ),
                array(
                    'type' => 'text',
                    'label' => $this->l('Public API Key'),
                    'name' => 'CODGUARD_PUBLIC_KEY',
                    'required' => true,
                    'desc' => $this->l('Your CodGuard public API key'),
                ),
                array(
                    'type' => 'text',
                    'label' => $this->l('Private API Key'),
                    'name' => 'CODGUARD_PRIVATE_KEY',
                    'required' => true,
                    'desc' => $this->l('Your CodGuard private API key'),
                ),
                array(
                    'type' => 'text',
                    'label' => $this->l('Rating Tolerance (%)'),
                    'name' => 'CODGUARD_RATING_TOLERANCE',
                    'required' => true,
                    'desc' => $this->l('Minimum acceptable customer rating (0-100). Default: 35'),
                ),
                array(
                    'type' => 'textarea',
                    'label' => $this->l('Rejection Message'),
                    'name' => 'CODGUARD_REJECTION_MESSAGE',
                    'required' => true,
                    'desc' => $this->l('Message shown to customers when COD is blocked'),
                ),
            ),
            'submit' => array(
                'title' => $this->l('Save'),
                'class' => 'btn btn-default pull-right'
            )
        );

        $helper = new HelperForm();
        $helper->module = $this;
        $helper->name_controller = $this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->currentIndex = AdminController::$currentIndex.'&configure='.$this->name;
        $helper->default_form_language = $default_lang;
        $helper->allow_employee_form_lang = $default_lang;
        $helper->title = $this->displayName;
        $helper->show_toolbar = true;
        $helper->toolbar_scroll = true;
        $helper->submit_action = 'submitCodGuardModule';

        // Load current values
        $helper->fields_value['CODGUARD_ENABLED'] = Configuration::get('CODGUARD_ENABLED');
        $helper->fields_value['CODGUARD_SHOP_ID'] = Configuration::get('CODGUARD_SHOP_ID');
        $helper->fields_value['CODGUARD_PUBLIC_KEY'] = Configuration::get('CODGUARD_PUBLIC_KEY');
        $helper->fields_value['CODGUARD_PRIVATE_KEY'] = Configuration::get('CODGUARD_PRIVATE_KEY');
        $helper->fields_value['CODGUARD_RATING_TOLERANCE'] = Configuration::get('CODGUARD_RATING_TOLERANCE');
        $helper->fields_value['CODGUARD_REJECTION_MESSAGE'] = Configuration::get('CODGUARD_REJECTION_MESSAGE');

        return $helper->generateForm($fields_form);
    }
}
